// Cortège — service worker : rend l'appli installable et l'ouvre même avec un réseau capricieux.
const CACHE = 'cortege-v20';
const SHELL = ['./', './index.html', './manifest.webmanifest', './icon-192.png', './icon-512.png', './av/singe.svg', './av/renard.svg', './av/ours.svg', './av/chat.svg', './av/grenouille.svg', './av/hibou.svg', './av/pingouin.svg', './av/lapin.svg', './av/singe-pause.svg', './av/singe-arrive.svg', './av/singe-off.svg', './av/renard-pause.svg', './av/renard-arrive.svg', './av/renard-off.svg', './av/ours-pause.svg', './av/ours-arrive.svg', './av/ours-off.svg', './av/chat-pause.svg', './av/chat-arrive.svg', './av/chat-off.svg', './av/grenouille-pause.svg', './av/grenouille-arrive.svg', './av/grenouille-off.svg', './av/hibou-pause.svg', './av/hibou-arrive.svg', './av/hibou-off.svg', './av/pingouin-pause.svg', './av/pingouin-arrive.svg', './av/pingouin-off.svg', './av/lapin-pause.svg', './av/lapin-arrive.svg', './av/lapin-off.svg'];
self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).catch(() => {}));
  self.skipWaiting();
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
// Réseau d'abord (pour toujours avoir la dernière version), cache en secours. Firebase, la carte, etc. ne passent pas par ici.
self.addEventListener('fetch', e => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.origin !== self.location.origin) return;
  e.respondWith(
    fetch(e.request).then(r => {
      if (r.ok && !u.search) { const copy = r.clone(); caches.open(CACHE).then(c => c.put(e.request, copy)); }
      return r;
    }).catch(() => caches.match(e.request, { ignoreSearch: true }).then(r => r || caches.match('./index.html')))
  );
});
