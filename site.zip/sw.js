// Cortège — service worker : rend l'appli installable et l'ouvre même avec un réseau capricieux.
const CACHE = 'cortege-v35';
const SHELL = ['./', './index.html', './manifest.webmanifest', './icon-192.png', './icon-512.png', './av/grenouille.webp', './av/loup.webp', './av/panthere.webp', './av/panda.webp', './av/corbeau.webp', './av/lynx.webp', './av/raton.webp', './av/tigre.webp', './av/singe.webp', './av/grenouille-pied.webp', './av/loup-pied.webp', './av/panthere-pied.webp', './av/panda-pied.webp', './av/corbeau-pied.webp', './av/lynx-pied.webp', './av/raton-pied.webp', './av/tigre-pied.webp', './av/singe-pied.webp'];
self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(SHELL)).catch(() => {}));
  self.skipWaiting();
});
self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== CACHE).map(k => caches.delete(k)))).then(() => self.clients.claim()));
});
// Réseau d'abord (pour toujours avoir la dernière version), cache en secours. Firebase, la carte, etc. ne passent pas par ici.
self.addEventListener('fetch', e => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET' || u.origin !== self.location.origin) return;
  e.respondWith(
    fetch(u.href, { cache: 'no-cache', credentials: 'same-origin' }).then(r => { // no-cache : toujours la dernière version (GitHub garde sinon 10 min en cache)
      if (r.ok && !u.search) { const copy = r.clone(); caches.open(CACHE).then(c => c.put(e.request, copy)); }
      return r;
    }).catch(() => caches.match(e.request, { ignoreSearch: true }).then(r => r || caches.match('./index.html')))
  );
});
